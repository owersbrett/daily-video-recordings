//
//  Generated code. Do not modify.
//  source: service.proto
//
// @dart = 2.12

// ignore_for_file: annotate_overrides, camel_case_types, comment_references
// ignore_for_file: constant_identifier_names, library_prefixes
// ignore_for_file: non_constant_identifier_names, prefer_final_fields
// ignore_for_file: unnecessary_import, unnecessary_this, unused_import

import 'dart:convert' as $convert;
import 'dart:core' as $core;
import 'dart:typed_data' as $typed_data;

@$core.Deprecated('Use numberArrayDescriptor instead')
const NumberArray$json = {
  '1': 'NumberArray',
  '2': [
    {'1': 'numbers', '3': 1, '4': 3, '5': 5, '10': 'numbers'},
  ],
};

/// Descriptor for `NumberArray`. Decode as a `google.protobuf.DescriptorProto`.
final $typed_data.Uint8List numberArrayDescriptor = $convert.base64Decode(
    'CgtOdW1iZXJBcnJheRIYCgdudW1iZXJzGAEgAygFUgdudW1iZXJz');

