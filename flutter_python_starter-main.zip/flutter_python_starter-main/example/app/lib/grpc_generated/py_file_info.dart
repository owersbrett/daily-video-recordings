// !Will be rewriten upon `prepare sources` or `build` actions by Flutter-Python starter kit
const versionFileName = 'server_py_version.txt';
const exeFileName = 'server_py_flutter';
const currentFileVersionFromAssets = '2023_09_08_11_58_20';
